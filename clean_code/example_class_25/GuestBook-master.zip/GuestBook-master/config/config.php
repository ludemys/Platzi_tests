<?php

return [
    'comments_file' => __DIR__.'/../comments.json',
];
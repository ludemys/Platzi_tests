<?php

return [
    'date_label' => 'Fecha',
    'author_label' => 'Autor',
    'comment_label' => 'Comentarios',
    'input_author' => 'Autor',
    'input_comment' => 'Comentario',
    'submit' => 'Agregar comentario',
];